# NOVA AI (Stage 1-2 prototype)

## Build with GitHub Actions (no PC needed)
1. Create a new GitHub repo and upload ALL files from this folder (keep `.github/workflows/build.yml`).
2. Open the repo > Actions tab > "Build APK" (it also runs on every push; or press "Run workflow").
3. When green, open the run > Artifacts > download `nova-ai-debug-apk`, unzip, install `app-debug.apk`
   (allow "Install unknown apps" for your browser/file manager).
4. If the build fails, open the failed step and send the error text.

## Using it
- Allow microphone. Tap "Enable Accessibility" > find NOVA AI > turn on.
- "Open app" launches an installed app by name. "Read screen", Back, Home, Scroll use the accessibility service.

## Status
Implemented: UI shell + animated orb, permission flow, app launcher, accessibility actions (read/click/scroll/type/back/home).
Not yet: voice conversation, AI planner, screen capture + vision, confirmations, history, backend. API keys will never be put in the app.
