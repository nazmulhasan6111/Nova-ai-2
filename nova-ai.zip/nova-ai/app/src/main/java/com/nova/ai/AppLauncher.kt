package com.nova.ai

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

data class AppInfo(val label: String, val packageName: String)

class AppLauncher(private val ctx: Context) {

    fun installedApps(): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun search(query: String) =
        installedApps().filter { it.label.contains(query.trim(), ignoreCase = true) }

    /** Returns true if an app matching [name] was launched. */
    fun launchByName(name: String): Boolean {
        val app = search(name).firstOrNull() ?: return false
        val intent = ctx.packageManager.getLaunchIntentForPackage(app.packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return true
    }
}
