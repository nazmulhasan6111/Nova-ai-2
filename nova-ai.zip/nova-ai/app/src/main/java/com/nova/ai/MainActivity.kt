package com.nova.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleResumeEffect

private val Navy = Color(0xFF05070F)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)

enum class NovaStatus { Paused, Listening, Thinking, Speaking, Executing }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Cyan, background = Navy, surface = Navy)) {
                NovaScreen()
            }
        }
    }
}

@Composable
fun NovaOrb(status: NovaStatus) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        1f, if (status == NovaStatus.Paused) 1.02f else 1.12f,
        infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    Canvas(Modifier.size(200.dp).scale(pulse)) {
        val c = Offset(size.width / 2, size.height / 2)
        drawCircle(Brush.radialGradient(listOf(Purple.copy(alpha = .45f), Color.Transparent), c, size.minDimension / 2), radius = size.minDimension / 2)
        drawCircle(Brush.radialGradient(listOf(Cyan, Purple, Navy), c, size.minDimension / 3.2f), radius = size.minDimension / 3.2f)
    }
}

@Composable
fun NovaScreen() {
    val ctx = LocalContext.current
    var a11y by remember { mutableStateOf(NovaAccessibilityService.isRunning) }
    var micOk by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    var status by remember { mutableStateOf(NovaStatus.Paused) }
    var appName by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("Ready. Voice and AI planner are not connected yet (Stage 3+).") }

    LifecycleResumeEffect(Unit) { a11y = NovaAccessibilityService.isRunning; onPauseOrDispose {} }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micOk = it }

    Column(
        Modifier.fillMaxSize().background(Navy).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("NOVA AI", color = Color.White, fontSize = 28.sp)
        Text("Your Personal AI Phone Agent", color = Cyan, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))
        NovaOrb(status)
        Text(status.name, color = Color.White, fontSize = 18.sp)
        Spacer(Modifier.height(20.dp))

        Button(onClick = { if (!micOk) micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
            modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(if (micOk) "Microphone: allowed" else "Allow microphone")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text(if (a11y) "Accessibility: ON" else "Enable Accessibility (opens Settings)")
        }
        Text("NOVA needs this to read the screen and tap/scroll/type for you. You turn it on manually and can turn it off any time.",
            color = Color(0xFF94A3B8), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))

        Spacer(Modifier.height(24.dp))
        OutlinedTextField(appName, { appName = it }, label = { Text("App name (e.g. Settings)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                status = NovaStatus.Executing
                log = if (AppLauncher(ctx).launchByName(appName)) "Launched: $appName" else "No app found matching \"$appName\""
                status = NovaStatus.Paused
            }) { Text("Open app") }
            Button(onClick = {
                val svc = NovaAccessibilityService.instance
                log = if (svc == null) "Enable Accessibility first." else svc.readScreenText().take(30).joinToString(" | ").ifBlank { "No readable text." }
            }) { Text("Read screen") }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { NovaAccessibilityService.instance?.goBack() }) { Text("Back") }
            OutlinedButton(onClick = { NovaAccessibilityService.instance?.goHome() }) { Text("Home") }
            OutlinedButton(onClick = { NovaAccessibilityService.instance?.scroll(true) }) { Text("Scroll") }
        }
        Spacer(Modifier.height(20.dp))
        Text(log, color = Color(0xFFCBD5E1), fontSize = 13.sp)
    }
}
